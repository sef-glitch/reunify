import { createVibecodeSDK } from "@vibecodeapp/backend-sdk";

export const vibecode = createVibecodeSDK();
